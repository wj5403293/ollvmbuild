start=$(date +%s)
/data/user/0/aidepro.top/no_backup/ndksupport-1710240003/android-ndk-aide/build/ndk-build
end=$(date +%s)
diff=$(( end - start ))
echo "星空:编译耗时：$diff 秒"
#include <stdio.h>

//fla bcf函数单独混淆
void 打印_bcf_(){
  printf("hello world混淆");
}

int main() {
    printf("hello world!");
    打印_bcf_();
    return 0;
}